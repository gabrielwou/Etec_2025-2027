const diaSemana = 3;
let nomeDia;
switch (diaSemana){
    case 0:
        nomeDia = "Segunda-feira"
        break;
    case 1:
        nomeDia = "Terça-feira"
        break;
    case 2:
        nomeDia = "Quarta-feira"
        break;
    case 3:
        nomeDia = "Quinta-feira"
        break;
    case 4:
        nomeDia = "Sexta-feira"
        break;
}
console.log("Hoje é : "+nomeDia);


const carro = 1;
let marcaCarro;
switch (carro){
    case 0:
        marcaCarro = "Chevrolet"
        break;
    case 1:
        marcaCarro = "Volkswagen"
        break;
    case 2:
        marcaCarro = "Fiat"
        break;
}
console.log("A marca do seu carro é : "+marcaCarro)
