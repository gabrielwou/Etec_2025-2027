//Criar um programa que imprima uma contagem regressiva de (10 a 1)
let contagem = 10
while (contagem > 0){
    console.log(contagem)
    contagem = contagem-1
}
