//Criar um programa que calcule e apresente o volume de um cubo.
let arestas = 25;
let volume = arestas*3;
console.log("O volume do cubo é: "+volume);
 
//Criar um programa que calcule o imc de um indivíduo.
let altura = 1.80;
let peso = 60;
let imc = peso/(altura*altura); 
console.log("O imc do indivíduo é: "+imc);