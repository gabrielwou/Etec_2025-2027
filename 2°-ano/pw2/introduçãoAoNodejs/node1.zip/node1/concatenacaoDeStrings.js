let nome = "Gabriel";
let sobrenome = "Penha";
let nome_completo = "Seu nome completo é: "+nome+" "+sobrenome;
console.log(nome_completo);

let nome2 = "Wesley";
let sobrenome2 = "Fernandes";
let nome_completo2 = "Seu nome completo é: "+nome2+" "+sobrenome2;
console.log(nome_completo2);